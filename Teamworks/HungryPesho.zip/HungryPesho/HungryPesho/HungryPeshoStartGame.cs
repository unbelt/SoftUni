﻿namespace HungryPesho
{
    public class HungryPeshoStartGame
    {
        public static void Main()
        {
            Engine.Engine.StartGame();
        }
    }
}