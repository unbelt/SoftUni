﻿namespace HungryPesho.Items
{
    public enum WeaponTypes
    {
        Unarmed,
        Sword,
        Staff,
        Dagger,
        Bow
    }
}