﻿namespace HungryPesho.Items
{
    public enum ArmorTypes
    {
        Naked,
        Helmet,
        Chest,
        Legs,
        Rings
    }
}