﻿namespace HungryPesho.Items
{
    public enum FoodTypes
    {
        Pizza,
        Chicken,
        Steak,
        Beer
    }
}