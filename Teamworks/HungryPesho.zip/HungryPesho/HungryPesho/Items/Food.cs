﻿namespace HungryPesho.Items
{
    public class Food : EffectItem
    {
        public FoodTypes FoodType { get; set; }
    }
}