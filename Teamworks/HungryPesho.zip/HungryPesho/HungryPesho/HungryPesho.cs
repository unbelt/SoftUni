﻿namespace HungryPesho
{


    public class HungryPeshoGame
    {
        public static void Main()
        {
            Engine.Engine.StartGame();
        }
    }
}