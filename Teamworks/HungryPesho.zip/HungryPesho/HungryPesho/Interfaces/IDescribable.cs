﻿namespace HungryPesho.Interfaces
{
    public interface IDescribable
    {
        string Name { get; set; }

        string Description { get; set; }
    }
}