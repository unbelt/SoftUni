﻿namespace HungryPesho.Interfaces
{
    public interface IEffectable
    {
        int HealthGained { get; set; }

        int EnergyGained { get; set; }
    }
}