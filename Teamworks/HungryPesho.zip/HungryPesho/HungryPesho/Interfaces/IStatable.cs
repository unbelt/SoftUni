﻿namespace HungryPesho.Interfaces
{
    public interface IStatable
    {
        int Agility { get; set; }

        int Strength { get; set; }

        int Intellect { get; set; }
    }
}