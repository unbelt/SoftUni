﻿namespace HungryPesho.Abilities
{
    public enum AbilityEffects
    {
        DirectDamage,
        DamageModificator,
        Freeze,
        Dodge, 
        Speed,
        Ultimate
    }
}