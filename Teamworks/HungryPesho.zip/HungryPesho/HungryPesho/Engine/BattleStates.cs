﻿namespace HungryPesho.Engine
{
    public enum BattleStates
    {
        Start,
        Player,
        Enemy,
        Lose,
        Win
    }
}
