﻿namespace HungryPesho.UI
{
    public enum Sound
    {
        Intro,
        Hit,
        Miss,
        Strike,
        Win,
        Lose,
        Credits,
        Ranklist,
        Click,
        Enter,
        Freeze,
        Death,
        Slam
    }
}